# Configuration Examples

These are **starting points**, not production configuration.

| File | Purpose |
|---|---|
| `managed-settings.example.json` | Organization-wide Claude Code policy: permission rules, environment, hooks. Deploy via MDM/config management to the managed settings location so individual users cannot override it. |
| `CLAUDE.md.example` | Repo-level project memory. Copy to the repo root as `CLAUDE.md` and tailor. Engineering Champions should own its quality. |

## Before deploying
1. Validate keys and file locations against current Claude Code documentation at [docs.claude.com](https://docs.claude.com).
2. Pilot with one team for 2 weeks; tune `allow`/`ask` lists to reduce approval fatigue without weakening `deny` rules.
3. Have Security review the `deny` list and any hooks.
4. Version-control your org settings and change them via pull request.
