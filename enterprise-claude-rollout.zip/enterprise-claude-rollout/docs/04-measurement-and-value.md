# Measurement & Value Realization

If you only measure logins, you will only be able to defend logins at renewal time. Measure three layers from day one.

---

## 1. The three-layer model

```
  VALUE        Did work outcomes improve?      ← what executives fund
    ▲
  PROFICIENCY  Are people using it well?       ← what champions build
    ▲
  ADOPTION     Are people using it at all?     ← leading indicator
```

---

## 2. Adoption metrics

| Metric | Definition | Healthy target (by month 6) |
|---|---|---|
| Activation rate | Users with ≥1 session / licensed users | ≥90% |
| Weekly active users (WAU) | Users active in a week / licensed | ≥60% |
| Depth | Avg. active days per week among WAU | ≥3 |
| Breadth | % of users using Projects, connectors, or Skills | ≥30% |
| Claude Code active engineers | Engineers with weekly sessions / enabled engineers | ≥60% |

Segment every metric by **function, region, level, and champion coverage**.

---

## 3. Proficiency metrics

| Metric | Source |
|---|---|
| Capability level (Explore → Assist → Delegate → Orchestrate) | Quarterly self-assessment + champion validation |
| Assets contributed to use-case library | Library / repo |
| Advanced feature usage | Admin analytics |
| Training completion | LMS |

---

## 4. Value metrics

### 4.1 Knowledge work

Baseline **5–10 target processes** in Phase 0. For each, capture:

| Process | Baseline time | Post-adoption time | Volume / month | Quality measure |
|---|---|---|---|---|
| e.g., Monthly variance commentary | 6 hrs | 2 hrs | 40 | Reviewer revisions |
| e.g., Contract first-pass review | 90 min | 35 min | 120 | Issues caught vs. missed |

Estimated hours released = (baseline − post) × volume. Report as **capacity redeployed**, and pair it with what that capacity was used for.

### 4.2 Engineering (Claude Code)

Use DORA-style and flow metrics, always paired:

| Speed | Paired quality guardrail |
|---|---|
| Lead time for changes | Change-failure rate |
| PR throughput per engineer | Defect escape rate |
| Cycle time (ticket → merge) | Rework / revert rate |
| Test coverage added | Security findings per release |

Speed gains that come with rising failure rates are not wins.

### 4.3 Experience

- Quarterly pulse: "Claude helps me do better work" (1–5)
- Net promoter-style question for the tool and for champion support
- Qualitative wins collected by champions

---

## 5. Reporting cadence

| Audience | Format | Frequency |
|---|---|---|
| Executive Sponsor / Steering Group | 1-page scorecard: adoption, value, risk, top 3 asks | Monthly |
| Function leaders | Function dashboard with champion commentary | Monthly |
| Champions | Network dashboard + feedback themes | Bi-weekly |
| All staff | Wins and progress story | Monthly |

---

## 6. Scorecard template

| Area | Metric | Target | Actual | Trend | Note |
|---|---|---|---|---|---|
| Adoption | WAU % | 60% | | | |
| Adoption | Champion coverage | ≤50:1 | | | |
| Proficiency | % at "Assist" or above | 50% | | | |
| Value | Hours redeployed / month | | | | |
| Value (Eng) | Lead time Δ / change-failure Δ | ↓ / ≤ baseline | | | |
| Risk | Open incidents / exceptions | 0 high | | | |
| Experience | Satisfaction | ≥4.0 | | | |
