# Rolling Out Claude & Claude Code in the Enterprise: A Best-Practices Guide

**Version 1.0 · October 2026**

---

## Executive summary

Most enterprise AI rollouts stall in the same place: licenses are bought, a launch email goes out, early adopters thrive, and the remaining 70–80% of the workforce logs in twice and drifts away. Twelve months later the renewal conversation hinges on anecdotes rather than evidence.

The organizations that break through treat AI adoption as a **behavior-change program with a technology component**, not the other way around. Their rollouts share five traits:

1. **Clear, enabling guardrails** published *before* launch, so people know what is allowed instead of guessing.
2. **A phased rollout** — pilot, scale, embed — with explicit exit criteria for each phase.
3. **A Business Champions network** of trusted peers who translate the tool into the language of each function.
4. **Use-case-led enablement** — training on real workflows ("close the month faster"), not features ("here is the chat box").
5. **Measurement from day one** — adoption, proficiency, and business value, reviewed monthly by an executive sponsor.

This guide covers both **Claude** (for knowledge workers across every function) and **Claude Code** (for software engineering teams), because the two programs reinforce each other and should share governance, champions infrastructure, and metrics — while differing in enablement and technical controls.

---

## Table of contents

1. [Principles](#1-principles)
2. [Operating model](#2-operating-model)
3. [Readiness assessment](#3-readiness-assessment)
4. [Phased rollout plan](#4-phased-rollout-plan)
5. [Claude: knowledge-worker rollout](#5-claude-knowledge-worker-rollout)
6. [Claude Code: engineering rollout](#6-claude-code-engineering-rollout)
7. [The Business Champions network](#7-the-business-champions-network)
8. [Enablement and training](#8-enablement-and-training)
9. [Communications](#9-communications)
10. [Governance, security, and risk](#10-governance-security-and-risk)
11. [Measurement](#11-measurement)
12. [Common failure modes](#12-common-failure-modes)
13. [90-day launch summary](#13-90-day-launch-summary)

---

## 1. Principles

| Principle | What it means in practice |
|---|---|
| **Enable first, restrict deliberately** | Default to "yes, with guardrails." Every restriction should trace to a specific risk. Over-restriction drives shadow AI. |
| **People before platform** | Budget at least as much effort for enablement and champions as for technical integration. |
| **Workflows, not features** | Teach Claude in the context of the work people already do. |
| **Peers over mandates** | A colleague showing a 20-minute time saving beats any executive memo. |
| **Human accountability stays** | AI drafts; humans decide, review, and own the outcome. |
| **Measure what matters** | Logins are a leading indicator, not a result. Track time, quality, and cycle-time outcomes. |
| **Iterate in the open** | Publish what's working, what isn't, and what's changing. Trust compounds. |

---

## 2. Operating model

### 2.1 Roles

| Role | Responsibilities | Typical time |
|---|---|---|
| **Executive Sponsor** (CIO/CTO/CAIO/COO) | Owns outcomes, removes blockers, chairs monthly review, models usage visibly | 2–4 hrs/month |
| **AI Steering Group** | Sets risk appetite, approves policy, prioritizes use cases, allocates funding. Includes Security, Legal, Privacy, Risk, HR, Engineering, and 2–3 business leaders | Monthly, 90 min |
| **AI Center of Enablement (CoE)** | Program management, platform admin, policy, training, champion network, metrics | 3–8 FTE for a 5k–20k user org |
| **Platform / Identity team** | SSO/SCIM, admin console, connectors, Claude Code managed settings, logging | Project-based |
| **Business Champions** | Peer coaching, use-case discovery, feedback loop for their function | 10–15% of role |
| **Engineering Champions** | Claude Code patterns, CLAUDE.md standards, code-review norms for their teams | 10–20% of role |
| **People managers** | Set expectations, protect learning time, recognize adoption | Ongoing |

See [`templates/raci.md`](../templates/raci.md) for a full RACI.

### 2.2 Champion ratios

- **Knowledge workers (Claude):** 1 Business Champion per 25–50 users, with at least one per department and one per major location or shift.
- **Engineering (Claude Code):** 1 Engineering Champion per team (or per 8–12 engineers), aligned to value streams or Agile Release Trains where they exist.

---

## 3. Readiness assessment

Score each dimension 1 (not ready) to 5 (ready). Any dimension scoring ≤2 should be addressed before scaling beyond pilot.

| Dimension | Key questions |
|---|---|
| **Sponsorship** | Is there a named executive accountable for outcomes, not just procurement? |
| **Policy** | Is there a published AI acceptable-use policy and data classification guidance? |
| **Identity & access** | Is SSO in place? Is user provisioning/deprovisioning automated (e.g., SCIM)? |
| **Data** | Do you know which data classes may be used with Claude, and which connectors are approved? |
| **Security** | Has Security reviewed vendor terms, data retention, and logging options? |
| **Engineering** | Do repos have CI, tests, branch protection, and code review? (Claude Code amplifies whatever engineering hygiene exists.) |
| **Change capacity** | Is the organization saturated with other transformations right now? |
| **Champions** | Can you identify credible, curious volunteers in every major function? |
| **Measurement** | Can you baseline the processes you intend to improve? |

---

## 4. Phased rollout plan

```
 Phase 0           Phase 1             Phase 2              Phase 3
 FOUNDATION   →    PILOT          →    SCALE           →    EMBED
 Weeks 0–4         Weeks 4–12          Months 3–9           Month 9+
 Policy, SSO,      100–500 users       Wave-based by        AI in standard
 CoE, champions    across 4–6          function / region    work, onboarding,
 recruited         functions + 3–5     Champions at 1:25–50 role design, and
                   eng. teams                               process metrics
```

### Phase 0 — Foundation (weeks 0–4)

- Name the Executive Sponsor and form the Steering Group.
- Stand up the CoE and an intake channel (e.g., a Teams/Slack channel + intake form).
- Complete security, legal, and privacy review; finalize the [acceptable-use policy](../templates/acceptable-use-policy.md).
- Configure SSO, automated provisioning, admin roles, and approved connectors.
- Draft Claude Code organization policy ([example](../config-examples/managed-settings.example.json)).
- Recruit the **first champion cohort** (pilot champions become the founding cohort).
- Baseline 5–10 target processes (time, cycle time, error rate).

**Exit criteria:** policy published; SSO live; ≥1 champion per pilot team; baselines captured.

### Phase 1 — Pilot (weeks 4–12)

- Select 4–6 business functions and 3–5 engineering teams with a mix of enthusiasm *and* skepticism. Avoid an all-volunteer pilot — it overstates results.
- Run a **use-case sprint** in each function: champions plus 3–5 users identify their top 5 candidate workflows.
- Deliver role-based training (see §8).
- Hold weekly champion stand-ups and bi-weekly pilot retros.
- Capture 10–20 documented "wins" with before/after data.

**Exit criteria:** ≥60% weekly active usage in pilot population; ≥5 validated use cases with measured value; no unresolved high-severity risk findings; Steering Group go decision.

### Phase 2 — Scale (months 3–9)

- Roll out in **waves** of 1,000–3,000 users, gated by champion coverage, not calendar.
- Each wave: champions trained 2 weeks ahead → manager briefing → launch → 30-day hypercare.
- Publish a **use-case library** (prompts, Projects, Skills, playbooks) curated by champions.
- Expand Claude Code to additional teams with shared CLAUDE.md standards and approved MCP servers.

**Exit criteria per wave:** ≥50% WAU at day 30; champion coverage maintained; satisfaction ≥4/5.

### Phase 3 — Embed (month 9+)

- Integrate AI expectations into onboarding, job descriptions, and performance conversations (as capability, not surveillance).
- Redesign end-to-end processes, not just individual tasks.
- Transition the champion network from "launch" to "community of practice."
- Move measurement from adoption to business KPIs owned by functional leaders.

---

## 5. Claude: knowledge-worker rollout

### 5.1 Start with high-frequency, low-risk, high-visibility work

| Function | Strong first use cases |
|---|---|
| **All staff** | Meeting prep and summaries, email drafting, document review, research synthesis |
| **Finance** | Variance commentary, policy Q&A, reconciliation explanations, board-deck narrative |
| **HR** | Job description drafts, policy FAQs, interview guides, learning content |
| **Legal / Compliance** | First-pass contract review against playbooks, regulatory change summaries |
| **Sales / Marketing** | Account research, proposal drafting, campaign variants, call prep |
| **Operations** | SOP drafting, root-cause narratives, vendor comparisons |
| **Customer Service** | Knowledge-article drafting, response templates, escalation summaries |

### 5.2 Build reusable assets, not just individual habits

- **Projects** — shared workspaces with team context and instructions (e.g., "Q4 Board Reporting").
- **Skills / prompt libraries** — packaged, repeatable procedures for common tasks ("draft a variance memo in house style").
- **Approved connectors** — to document stores, ticketing, and collaboration tools, scoped by data classification.

Champions own curation of these assets for their function. The CoE owns quality standards and the central catalog.

### 5.3 Guidance every user needs on day one

1. What data you may and may not use (one-page summary of the AUP).
2. You are accountable for anything you send, publish, or decide using Claude's output.
3. Verify facts, figures, and citations before relying on them.
4. Where to get help (your champion, the CoE channel).
5. How to share a win.

---

## 6. Claude Code: engineering rollout

Claude Code is an agentic tool that reads code, runs commands, and edits files. That makes it dramatically more capable than autocomplete — and means engineering hygiene and permission design matter more.

### 6.1 Prerequisites per team

- Repos under version control with **branch protection** and **required code review**.
- CI with automated tests and linting — Claude Code is most effective (and safest) when it can verify its own work.
- Secrets in a vault, not in repos or `.env` files checked into source.
- A team **Engineering Champion** identified.

### 6.2 Organization-level controls

Work with your platform team to define org-wide policy using Claude Code's managed settings capability (validate keys against current docs). Typical controls:

- **Permission rules** — allow common safe commands (test runners, linters, `git status/diff`), require approval for writes outside the repo, and deny reading secrets files or running destructive commands.
- **Approved MCP servers** — an allowlist of integrations (issue tracker, internal docs, observability) reviewed by Security.
- **Model and data settings** — route through your enterprise account; disable non-essential telemetry if required by policy.
- **Hooks** — e.g., run secret scanners or formatters automatically.
- **Audit and usage analytics** — export to your SIEM or analytics platform where available.

See [`config-examples/managed-settings.example.json`](../config-examples/managed-settings.example.json).

### 6.3 Repo-level standards

Every participating repo should include a **`CLAUDE.md`** project memory file containing:

- Architecture overview and key directories
- Build, test, and lint commands
- Coding conventions and patterns to follow / avoid
- Definition of done (tests required, docs updated, etc.)
- Anything Claude should never touch (generated code, migrations without review)

Starter: [`config-examples/CLAUDE.md.example`](../config-examples/CLAUDE.md.example).

### 6.4 Adoption progression for engineers

| Stage | Typical activity | Champion focus |
|---|---|---|
| **1. Explore** | Codebase Q&A, explaining unfamiliar code, writing tests | Safe first wins, permission basics |
| **2. Assist** | Bug fixes, small features, refactors with human review of every diff | CLAUDE.md quality, prompt patterns, plan-first workflows |
| **3. Delegate** | Multi-file features, migrations, PR creation, CI-triggered tasks | Task decomposition, verification strategies, review norms |
| **4. Orchestrate** | Parallel agents, custom slash commands, Skills, team plugins, automated pipelines | Shared tooling, governance of automation |

### 6.5 Non-negotiables

- **Humans review and own every merged change.** "Claude wrote it" is never a review exemption.
- AI-assisted PRs follow the same review, test, and security-scan gates as any other.
- Track defect escape rate and change-failure rate alongside velocity — speed without quality is not a win.

---

## 7. The Business Champions network

Champions are the single biggest predictor of broad adoption. They are not help desk staff and not evangelists for the vendor; they are **trusted practitioners who make AI relevant to their peers' actual work**.

### 7.1 What champions do

1. **Coach** — office hours, desk-side help, "show me your workflow" sessions.
2. **Discover** — surface and document high-value use cases in their function.
3. **Curate** — maintain their function's Projects, prompts, and Skills.
4. **Translate** — turn central policy and features into "here's what it means for us."
5. **Listen** — feed friction, risks, and requests back to the CoE.
6. **Celebrate** — make wins visible.

### 7.2 Who makes a great champion

Credibility with peers matters more than technical skill. Look for people who are curious, generous with their time, respected for the quality of their work, and representative of the function — including some healthy skeptics.

### 7.3 Making the role real

- **Protected time** (10–15% / ~half a day per week), agreed with their manager in writing.
- **Early access** to new features and a direct line to the CoE.
- **Advanced training** (cohort-based, 4–6 weeks).
- **Recognition** — badges, leadership visibility, performance-review credit.
- **A term** (e.g., 12 months, renewable) to prevent burnout.

Full detail: [Business Champions Playbook](02-business-champions-playbook.md).

---

## 8. Enablement and training

| Audience | Format | Content |
|---|---|---|
| **All users** | 60-min live or recorded + 1-page quick start | Policy essentials, prompting basics, 3 function-specific use cases, where to get help |
| **People managers** | 45-min briefing | How to set expectations, protect learning time, recognize use, handle concerns |
| **Champions** | 4–6 week cohort (2 hrs/week) | Advanced prompting, Projects/Skills, connectors, coaching skills, use-case documentation, risk recognition |
| **Engineers** | 2-hr hands-on lab per team, led by Engineering Champion on the team's own repo | Permissions, CLAUDE.md, plan-then-execute, test-driven prompting, review norms |
| **Executives** | 30-min personal session | Their own use cases — leaders who use it visibly drive adoption |

**Best practice:** Replace generic training with **"work-along" sessions** where users bring a real task and complete it with a champion. Retention and adoption are markedly higher than with demos.

---

## 9. Communications

| When | Message | Messenger |
|---|---|---|
| T–4 weeks | Why we're doing this, what it means for jobs, the guardrails | Executive Sponsor |
| T–2 weeks | Meet your champions; what to expect | Function leaders + champions |
| Launch | How to get access, quick start, office hours | CoE + champions |
| Weekly (first 8 weeks) | Tip of the week, a peer win | Champions |
| Monthly | Metrics, what changed, what's next | Executive Sponsor |

**Address the job question directly.** Unspoken fear of replacement is the most common silent adoption killer. State plainly how the organization intends to use productivity gains (capacity for higher-value work, growth, reduced backlog) and stick to it.

---

## 10. Governance, security, and risk

Summary below; full detail in [Governance & Security](03-governance-and-security.md).

- **Data classification mapping** — which data classes are permitted in Claude, in which product surfaces, and via which connectors.
- **Acceptable-use policy** — short, plain-language, published before launch.
- **Use-case risk tiering** — low-risk productivity use is self-service; customer-facing, regulated, or automated-decision use cases require review.
- **Model risk management** — in regulated industries, determine whether and how AI-assisted processes fall under existing model risk frameworks (e.g., SR 11-7 in U.S. banking) and document accordingly.
- **Logging and audit** — enable available audit logs and usage analytics; define retention.
- **Incident process** — how users report a concerning output or data exposure, and who responds.

---

## 11. Measurement

Track three layers. Detail in [Measurement & Value](04-measurement-and-value.md).

| Layer | Example metrics |
|---|---|
| **Adoption** | Weekly active users (WAU) / licensed, depth (days active per week), feature breadth (Projects, connectors, Claude Code sessions) |
| **Proficiency** | Self-assessed and champion-assessed capability levels, use-case library contributions, advanced feature usage |
| **Value** | Time saved on baselined processes, cycle time, quality/error rates, lead time for changes, PR throughput with stable change-failure rate, employee sentiment |

---

## 12. Common failure modes

| Failure mode | Symptom | Countermeasure |
|---|---|---|
| **License-and-pray** | Strong week-one numbers, steep decline | Champions + use-case-led training before launch |
| **Policy paralysis** | Months of review, no pilot | Time-box Phase 0; tier risk so low-risk use can proceed |
| **Over-restriction** | Users revert to personal accounts | Enable-first policy; explain every restriction |
| **Champion burnout** | Champions go quiet after 3 months | Protected time, terms, recognition, manager agreement |
| **Vanity metrics** | Reports show logins, not outcomes | Baseline processes in Phase 0 |
| **Engineering without guardrails** | AI-generated code bypasses review | Branch protection, required review, CI gates, managed settings |
| **Silent job anxiety** | Polite non-adoption | Direct, honest leadership communication |
| **Pilot only with enthusiasts** | Results don't replicate at scale | Include skeptics and average performers in pilots |

---

## 13. 90-day launch summary

| Days | Key activities |
|---|---|
| **1–30** | Sponsor named · Steering Group formed · AUP published · SSO/provisioning · Champion cohort recruited and trained · Claude Code policy drafted · Baselines captured |
| **31–60** | Pilot launch (Claude + Claude Code) · Use-case sprints · Weekly champion stand-ups · First wins documented |
| **61–90** | Pilot retro and metrics review · Use-case library v1 · Steering Group scale decision · Wave 1 champions onboarded |

Detailed checklist: [`templates/90-day-launch-checklist.md`](../templates/90-day-launch-checklist.md).

---

*This guide is independent and not affiliated with or endorsed by Anthropic. Validate product capabilities against current documentation at [docs.claude.com](https://docs.claude.com).*
