# Governance, Security & Risk

Guardrails should make the safe path the easy path. This document outlines a governance model proportionate to risk, so that low-risk productivity use can move quickly while high-impact uses receive appropriate scrutiny.

> Validate all product-specific capabilities (data retention, audit logs, admin controls, connector governance) against current Anthropic documentation and your contract terms.

---

## 1. Governance structure

| Body | Purpose | Cadence |
|---|---|---|
| **AI Steering Group** | Risk appetite, policy approval, portfolio prioritization | Monthly |
| **AI Risk Review** (sub-group: Security, Privacy, Legal, Risk, domain expert) | Reviews Tier 2–3 use cases | Weekly / on demand |
| **CoE** | Operates policy, platform configuration, and monitoring | Ongoing |

---

## 2. Use-case risk tiering

| Tier | Description | Examples | Approval |
|---|---|---|---|
| **Tier 1 — Personal productivity** | Human-in-the-loop, internal, non-sensitive or approved data | Drafting, summarizing, research, internal code assistance | Self-service under AUP |
| **Tier 2 — Team / process** | Shared assets, approved connectors to internal systems, outputs used by others | Team Projects on confidential data, Claude Code in production repos, MCP integrations | Champion + CoE review, logged in register |
| **Tier 3 — High impact** | Customer-facing, regulated, automated decisions, or restricted data | Customer communications at scale, credit/HR decisions support, autonomous agents with write access to production systems | AI Risk Review, documented controls, monitoring plan, periodic re-validation |

All Tier 2–3 use cases are recorded in an **AI use-case register** (owner, data classes, controls, review date).

---

## 3. Data handling

Map your existing data classification scheme to permitted use:

| Classification | Claude (chat/Projects) | Connectors | Claude Code |
|---|---|---|---|
| Public | ✅ | ✅ | ✅ |
| Internal | ✅ | ✅ Approved only | ✅ |
| Confidential | ✅ Enterprise account only, per policy | ✅ Approved, scoped | ✅ With repo controls |
| Restricted (e.g., PCI, PHI, regulated PII, secrets) | ❌ unless specifically approved Tier 3 | ❌ unless approved | ❌ — deny read access to secrets files |

*Example only — set these with Privacy, Security, and Legal.*

Key controls:
- Use only **enterprise-managed accounts**; prohibit work data in personal accounts.
- Review contractual terms for **data retention, training use, and data residency**.
- Enforce **SSO** and automated **provisioning/deprovisioning**.
- Restrict connectors to an **approved list** with least-privilege scopes.

---

## 4. Claude Code-specific controls

| Risk | Control |
|---|---|
| Destructive or unintended commands | Permission rules (deny/ask/allow), sandboxing where available, run in dev environments |
| Secrets exposure | Deny reads of secrets files; secret scanning hooks and pre-commit checks; vault-based secrets |
| Unreviewed code reaching production | Branch protection, required human review, CI gates — identical for AI-assisted changes |
| Untrusted integrations / prompt injection | Allowlist MCP servers; review third-party servers; treat external content (web pages, issues, docs) as untrusted input |
| Supply chain | Dependency scanning; require approval for new dependencies |
| Shadow configuration | Organization-managed settings that individual users cannot override |

---

## 5. Model risk management (regulated industries)

For financial services and other regulated sectors:

- Determine whether a given AI-assisted process meets your institution's definition of a "model" under frameworks such as **SR 11-7 / OCC 2011-12**.
- For in-scope uses: document intended use, limitations, validation approach, ongoing monitoring, and human-oversight controls.
- Maintain an inventory linking AI use cases to the model inventory where applicable.
- Most Tier 1 productivity use with full human review will not be "models" in the regulatory sense — but document that determination.

Also consider applicable regimes such as the EU AI Act, state AI laws, sector privacy rules, and employment-law considerations for HR use cases.

---

## 6. Monitoring and audit

- Enable available **audit logs** and **usage analytics**; export to SIEM / analytics where supported.
- Define retention aligned to your records policy.
- Review Tier 3 use cases on a defined cadence (e.g., quarterly).
- Track policy exceptions and incidents as a Steering Group metric.

---

## 7. Incident response

1. **Report** — single channel (e.g., `[CoE EMAIL]` or security hotline) for data exposure, harmful output, or misuse.
2. **Triage** — CoE + Security within one business day; immediately for suspected data exposure.
3. **Contain** — disable connector, revoke access, or adjust policy as needed.
4. **Learn** — blameless review; update policy, training, or configuration; share lessons with champions.
