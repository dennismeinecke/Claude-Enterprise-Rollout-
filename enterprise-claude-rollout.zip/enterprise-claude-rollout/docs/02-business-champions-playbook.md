# Business Champions Playbook

The champions network is the adoption engine of an enterprise Claude rollout. This playbook covers how to design, recruit, enable, run, and sustain it.

---

## 1. Why champions work

Enterprise software adoption follows a predictable pattern: central teams can provide access and training, but behavior changes when someone **you already trust** shows you how a tool makes **your** work easier. Champions close three gaps that central teams cannot:

| Gap | How champions close it |
|---|---|
| **Relevance** | They translate general capability into function-specific workflows. |
| **Trust** | Peers are more credible than vendors, IT, or executives on "is this actually useful?" |
| **Feedback** | They surface friction, risks, and opportunities the CoE would never see. |

---

## 2. Network design

### 2.1 Structure

```
CoE Champion Lead (1 FTE)
   │
   ├── Lead Champions (1 per business unit / region)  — coordinate, escalate, mentor
   │       │
   │       └── Business Champions (1 per 25–50 users) — coach, discover, curate
   │
   └── Engineering Champion Lead
           │
           └── Engineering Champions (1 per team / 8–12 engineers)
```

### 2.2 Coverage rules

- At least **one champion per department**, per **major site**, and per **shift** for operations.
- Mix of seniority levels — not only managers, not only early-career staff.
- At least **20% healthy skeptics** — they ask the questions everyone else is thinking, and their conversions are the most persuasive.

---

## 3. Recruiting

### 3.1 Selection criteria

| Must have | Nice to have |
|---|---|
| Respected by peers for quality of work | Prior experience with AI tools |
| Curious and willing to experiment | Training or facilitation experience |
| Generous — likes helping others | Process improvement background (Lean, Agile, Six Sigma) |
| Manager support for protected time | Cross-functional network |
| Good judgment on data and risk | |

### 3.2 Process

1. **Nominations** — open self-nomination plus manager nominations ([form](../templates/champion-nomination-form.md)).
2. **Short conversation** (15 min) — motivation, availability, a workflow they'd like to improve.
3. **Manager agreement** — signed [charter](../templates/champion-charter.md) confirming protected time.
4. **Announcement** — leadership publicly names the cohort. Visibility is part of the reward.

---

## 4. Enablement: the Champion Academy

A 6-week cohort, ~2 hours/week, delivered by the CoE.

| Week | Theme | Outcome |
|---|---|---|
| 1 | Foundations & policy | Can explain the AUP and data rules in plain language |
| 2 | Effective prompting & context | Can coach peers from vague prompts to strong ones |
| 3 | Projects, Skills, connectors | Has built a team Project and one reusable Skill/prompt asset |
| 4 | Use-case discovery & documentation | Has documented 2 use cases with before/after estimates |
| 5 | Coaching & change leadership | Can run a 30-min work-along session; handles resistance constructively |
| 6 | Risk recognition & escalation | Knows how to spot and escalate data, accuracy, or misuse concerns; graduation showcase |

**Engineering Champion track** replaces weeks 2–3 with: Claude Code permissions model, CLAUDE.md authoring, plan-then-execute workflows, test-driven prompting, MCP servers, custom commands, and code-review norms for AI-assisted changes.

---

## 5. Operating rhythm

| Cadence | Activity | Owner |
|---|---|---|
| Weekly (launch phase) | 30-min champion stand-up: wins, blockers, risks | CoE Champion Lead |
| Weekly | Office hours in each function (30–60 min) | Business Champions |
| Bi-weekly | Tip-of-the-week post to function channel | Champions (rotating) |
| Monthly | Champion community call: new features, showcase, feedback themes | CoE |
| Monthly | Feedback digest to Steering Group | CoE Champion Lead |
| Quarterly | Use-case library review and pruning | Lead Champions |
| Quarterly | Recognition and renewal check-in | CoE + managers |

---

## 6. Champion toolkit

Each champion receives:

- **Quick-start one-pager** for their function
- **Work-along session guide** (30-minute format: pick a real task → do it together → save the prompt/asset → schedule follow-up)
- **Use-case template** ([use-case-intake.md](../templates/use-case-intake.md))
- **"Common objections" guide** (see §7)
- **Escalation path** for risk or policy questions
- **Early-access** to new features and a private champion channel

---

## 7. Handling common objections

| Objection | Champion response pattern |
|---|---|
| "It makes things up." | "It can. That's why you verify facts and figures — let me show you how to ask it to cite its sources from your documents, and when to double-check." |
| "I don't have time to learn this." | "Give me 30 minutes on something you're doing this week. If it doesn't save you time, I won't ask again." |
| "Is this going to replace my job?" | Acknowledge the concern honestly; share leadership's stated commitment; focus on the parts of the job people dislike. Escalate patterns to the CoE. |
| "I'm not allowed to use real data." | "Here's exactly what you can use" — point to the one-page data guide. |
| "My work is too specialized." | "Let's try it on one piece of it." Specialized work often benefits most from a well-built Project with domain context. |

---

## 8. Recognition and sustainability

- **Visible credit** — named in leadership communications; showcase slots at town halls.
- **Career value** — champion work recognized in performance reviews; leadership-development exposure.
- **Digital badges** and a champion directory.
- **Fixed terms** (12 months, renewable) with graceful rotation to prevent burnout and spread capability.
- **Alumni network** — former champions remain a resource and mentor new cohorts.

**Warning signs of a struggling network:** declining stand-up attendance, falling office-hour traffic, managers reclaiming protected time, champions unable to name recent wins. Act within one month — usually by re-confirming manager commitments and refreshing the content pipeline.

---

## 9. Measuring champion impact

| Metric | Target |
|---|---|
| Champion coverage (users per champion) | ≤50 |
| Active usage among teams with an active champion vs. without | Track the gap — typically the strongest evidence for the model |
| Use cases documented per champion per quarter | ≥2 |
| Office-hour / work-along sessions per month | ≥2 |
| Champion retention through term | ≥80% |
| Champion satisfaction (quarterly pulse) | ≥4/5 |
