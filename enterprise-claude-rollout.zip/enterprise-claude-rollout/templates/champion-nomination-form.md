# AI Champion Nomination

1. **Nominee name / title / team:**
2. **Nominated by:** ☐ Self ☐ Manager ☐ Peer
3. **Why is this person respected by their peers?**
4. **Describe a workflow in your team you'd like to improve with AI:**
5. **Prior experience with AI tools (none is fine):**
6. **Experience coaching, training, or leading change (optional):**
7. **Can you commit 10–15% of your time for 12 months?** ☐ Yes ☐ Need to discuss
8. **Manager approval:** Name ________ ☐ Approved

*Healthy skepticism is welcome — some of our best champions start as doubters.*
