# Use-Case Intake & Documentation

| Field | Response |
|---|---|
| **Use-case name** | |
| **Function / team** | |
| **Owner** | |
| **Champion** | |
| **Product** | ☐ Claude ☐ Claude Code ☐ Both |
| **Problem / current process** | |
| **How Claude is used** (prompt, Project, Skill, connector, command) | |
| **Data classes involved** | ☐ Public ☐ Internal ☐ Confidential ☐ Restricted |
| **Risk tier** | ☐ 1 Personal ☐ 2 Team/process ☐ 3 High impact |
| **Human review step** | |
| **Baseline** (time, volume, quality) | |
| **Result** (time, volume, quality) | |
| **Estimated monthly hours redeployed** | |
| **Reusable asset link** | |
| **Lessons / caveats** | |
| **Status** | ☐ Idea ☐ Piloting ☐ Validated ☐ Scaled ☐ Retired |
