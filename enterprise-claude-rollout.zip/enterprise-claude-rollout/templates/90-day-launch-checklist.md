# 90-Day Launch Checklist

## Days 1–30 — Foundation
- [ ] Executive Sponsor named and outcomes defined
- [ ] AI Steering Group chartered
- [ ] CoE staffed (program lead, platform admin, champion lead, enablement)
- [ ] Vendor security, privacy, and legal review complete
- [ ] Acceptable-use policy approved and published
- [ ] Data classification mapping complete
- [ ] SSO + automated provisioning configured
- [ ] Admin roles assigned; audit logging enabled where available
- [ ] Approved connector list v1
- [ ] Claude Code managed settings drafted and tested with one team
- [ ] CLAUDE.md standard agreed
- [ ] Champion cohort 1 recruited, charters signed
- [ ] Champion Academy started
- [ ] 5–10 processes baselined
- [ ] Executive launch communication sent

## Days 31–60 — Pilot
- [ ] Pilot users provisioned (business functions + engineering teams)
- [ ] All-user and manager training delivered
- [ ] Engineering hands-on labs completed per team
- [ ] Use-case sprints held in each pilot function
- [ ] Weekly champion stand-ups running
- [ ] Office hours scheduled in each function
- [ ] Use-case register live
- [ ] First 5 wins documented with data

## Days 61–90 — Decide & prepare to scale
- [ ] Pilot metrics scorecard produced
- [ ] Pilot retrospective (users, champions, managers)
- [ ] Policy and configuration updates from lessons learned
- [ ] Use-case library v1 published
- [ ] Steering Group scale decision
- [ ] Wave plan defined (gated by champion coverage)
- [ ] Wave 1 champions recruited and in Academy
- [ ] All-staff progress story published
