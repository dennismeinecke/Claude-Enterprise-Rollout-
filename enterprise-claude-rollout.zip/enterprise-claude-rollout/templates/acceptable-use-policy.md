# AI Acceptable Use Policy — Plain-Language Template

> **Template only.** Review and adapt with Legal, Privacy, Security, and HR before publishing.

**Applies to:** All [ORG] employees and contractors using Claude, Claude Code, or other approved AI tools.
**Owner:** [CoE / CISO]  **Effective:** [DATE]  **Review:** Annually

## 1. Use approved tools and accounts
Use only [ORG]-provisioned enterprise accounts for work. Do not put [ORG] data into personal AI accounts or unapproved tools.

## 2. Know what data you can use
| You may use | Only with approval | Never |
|---|---|---|
| Public and Internal information | Confidential data in team Projects or approved connectors | Restricted data [list: payment card data, health information, passwords/secrets, ...] unless an approved Tier 3 use case allows it |

## 3. You own the output
AI drafts; you decide. You are accountable for anything you send, publish, merge, or decide using AI output. Verify facts, figures, citations, and code.

## 4. Be transparent when it matters
Disclose AI assistance where required by [ORG] policy, client contracts, or regulation, and whenever a reasonable recipient would expect to know.

## 5. Don't use AI for prohibited purposes
Including: making final employment, credit, or similar consequential decisions about people without approved process and human review; generating content that is discriminatory, harassing, or deceptive; circumventing security controls; or infringing others' intellectual property.

## 6. Code and automation (Claude Code)
- All AI-assisted code changes go through standard review, testing, and security gates.
- Do not grant AI tools access to production systems or secrets outside approved configurations.
- Use only approved integrations (MCP servers) and do not override organization-managed settings.

## 7. Report concerns
Report suspected data exposure, harmful output, or misuse to [CoE EMAIL / security channel] promptly. Good-faith reports will not be penalized.

## 8. Get help
Contact your AI Champion or the CoE at [CHANNEL].
