# RACI — Enterprise Claude Rollout

R = Responsible · A = Accountable · C = Consulted · I = Informed

| Activity | Exec Sponsor | Steering Group | CoE | Platform / IAM | Security / Legal / Privacy | Champions | People Managers |
|---|---|---|---|---|---|---|---|
| Strategy & outcomes | A | R | C | I | C | I | I |
| Acceptable-use policy | I | A | R | C | R | C | I |
| SSO, provisioning, admin config | I | I | C | A/R | C | I | I |
| Claude Code managed settings | I | I | C | R | C | C (Eng) | I |
| Connector / MCP approvals | I | A | R | R | R | C | I |
| Champion recruiting | I | I | A/R | I | I | C | R |
| Training & enablement | I | I | A/R | I | C | R | C |
| Use-case library | I | I | A | I | C | R | I |
| Tier 3 use-case approvals | I | A | R | C | R | C | I |
| Metrics & reporting | I | C | A/R | C | I | C | I |
| Protecting learning / champion time | C | I | C | I | I | I | A/R |
| Incident response | I | I | R | R | A | C | I |
