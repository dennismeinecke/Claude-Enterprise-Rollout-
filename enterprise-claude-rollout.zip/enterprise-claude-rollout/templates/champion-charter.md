# AI Champion Charter

**Organization:** [ORG]  **Function / Team:** __________  **Term:** [START] – [END] (12 months, renewable)

## Purpose
As an AI Champion, you help colleagues in your function use Claude [and Claude Code] safely and effectively, and you represent your function's needs to the AI Center of Enablement (CoE).

## Responsibilities
- Host at least **2 office hours or work-along sessions per month**
- Document at least **2 use cases per quarter** in the use-case library
- Maintain your function's shared Projects, prompts, and Skills
- Attend the weekly champion stand-up (launch phase) and monthly community call
- Share feedback, friction, and risk concerns with the CoE
- Model responsible use consistent with the Acceptable Use Policy

## Time commitment
**10–15% of working time** (approx. half a day per week), protected by your manager.

## What you receive
- Champion Academy training and early access to new capabilities
- Direct line to the CoE and private champion channel
- Recognition in leadership communications and performance reviews
- Champion badge and listing in the champion directory

## Agreement

| | Name | Signature | Date |
|---|---|---|---|
| Champion | | | |
| Manager | | | |
| CoE Champion Lead | | | |
