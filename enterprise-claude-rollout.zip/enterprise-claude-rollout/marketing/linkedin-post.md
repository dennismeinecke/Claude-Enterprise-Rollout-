# LinkedIn Post

---

Most enterprise AI rollouts don't fail on technology.

They fail in week three — when the launch email is forgotten, early adopters are thriving, and everyone else has quietly gone back to the old way of working.

I've led transformations across 120 teams and governed AI/ML at scale in a regulated bank. The pattern is always the same: **licenses don't change behavior. Trusted peers do.**

So I wrote an open playbook for rolling out Claude and Claude Code across a large enterprise — and put it on GitHub so anyone can fork it.

The core idea: build a **Business Champions network** before you scale.

🔹 1 champion per 25–50 users, in every function, site, and shift
🔹 Protected time (10–15%), signed off by their manager — not "volunteer on top of your day job"
🔹 A 6-week Champion Academy focused on real workflows, not feature tours
🔹 At least 20% healthy skeptics in the cohort — their conversions persuade everyone else
🔹 Engineering Champions per team for Claude Code, owning CLAUDE.md standards and review norms

What else is inside:

✅ A phased plan — Foundation → Pilot → Scale → Embed — with exit criteria for each phase
✅ Risk-tiered governance so low-risk use moves fast and high-impact use gets real scrutiny
✅ Claude Code guardrails: managed settings, permission rules, MCP allowlists, and "humans own every merge"
✅ A three-layer scorecard: adoption → proficiency → value (with quality guardrails paired to every speed metric)
✅ Ready-to-use templates: champion charter, nomination form, AUP, RACI, use-case intake, 90-day checklist

One lesson I'd underline: **address the job question out loud.** Silent anxiety about replacement is the most common reason people politely don't adopt.

🔗 Repo: [LINK]

If you're leading an AI rollout right now — what's been your biggest adoption blocker? I'd love to hear it in the comments.

#AI #Claude #ClaudeCode #AIAdoption #ChangeManagement #DigitalTransformation #EnterpriseAI #ChiefAIOfficer

---

## Posting notes

- Replace `[LINK]` with the repo URL. Consider putting the link in the first comment if you want to maximize reach.
- Best times: Tue–Thu mornings in your audience's time zone.
- Suggested image: the operating-model diagram from the README, or a simple graphic reading "Licenses don't change behavior. Trusted peers do."
- Follow up 1 week later with a carousel post on the 6-week Champion Academy.
