# Contributing

Contributions from practitioners are welcome — especially real-world lessons, templates, and metrics.

1. Open an issue describing the change or lesson.
2. Fork, create a branch, and submit a pull request.
3. Keep content vendor-accurate: link to official documentation for product-specific claims.
4. Do not include confidential information from any employer or client.

By contributing, you agree your contribution is licensed under CC BY 4.0.
