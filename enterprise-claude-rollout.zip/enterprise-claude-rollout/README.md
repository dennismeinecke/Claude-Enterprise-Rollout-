# Enterprise Rollout Playbook: Claude & Claude Code

A practical, field-tested guide for rolling out **Claude** (knowledge work) and **Claude Code** (agentic software engineering) across a large enterprise — with a **Business Champions network** as the engine of adoption.

> Tools don't transform organizations. People who show their peers what "good" looks like do.

**Author:** Dennis Meinecke — Fractional Chief AI Officer, [DRM Consulting LLC](https://drmconsulting.services)
**Version:** 1.0 · October 2026
**License:** [CC BY 4.0](LICENSE)

---

## Who this is for

| Role | Start here |
|------|-----------|
| CIO / CTO / CAIO sponsoring the rollout | [Rollout Guide](docs/01-rollout-guide.md) — Executive Summary & Phased Plan |
| Transformation / Change lead | [Business Champions Playbook](docs/02-business-champions-playbook.md) |
| CISO, Risk, Legal, Model Risk | [Governance & Security](docs/03-governance-and-security.md) |
| Engineering leadership / Platform team | [Rollout Guide §6](docs/01-rollout-guide.md#6-claude-code-engineering-rollout) + [config-examples/](config-examples/) |
| PMO / Finance | [Measurement & Value Realization](docs/04-measurement-and-value.md) |

## Repository contents

```
.
├── README.md
├── docs/
│   ├── 01-rollout-guide.md               # The core best-practices paper
│   ├── 02-business-champions-playbook.md # Recruiting, enabling, and sustaining champions
│   ├── 03-governance-and-security.md     # Guardrails, data handling, model risk
│   └── 04-measurement-and-value.md       # Adoption, proficiency, and value metrics
├── templates/
│   ├── champion-charter.md
│   ├── champion-nomination-form.md
│   ├── use-case-intake.md
│   ├── acceptable-use-policy.md
│   ├── raci.md
│   └── 90-day-launch-checklist.md
├── config-examples/
│   ├── managed-settings.example.json     # Org-level Claude Code policy (starter)
│   ├── CLAUDE.md.example                 # Repo-level project memory starter
│   └── README.md
├── marketing/
│   └── linkedin-post.md                  # Companion LinkedIn post
├── CONTRIBUTING.md
└── LICENSE
```

## The model in one picture

```
            ┌──────────────────────────────────────────┐
            │   Executive Sponsor + AI Steering Group  │  Direction, funding, risk appetite
            └────────────────────┬─────────────────────┘
                                 │
            ┌────────────────────▼─────────────────────┐
            │      AI Center of Enablement (CoE)       │  Platform, policy, training, metrics
            └───────┬──────────────────────────┬───────┘
                    │                          │
     ┌──────────────▼──────────┐   ┌───────────▼──────────────┐
     │ Business Champions      │   │ Engineering Champions    │  1 per ~25–50 users
     │ (Claude: Ops, Finance,  │   │ (Claude Code: per team / │
     │  HR, Legal, Sales...)   │   │  value stream)           │
     └──────────────┬──────────┘   └───────────┬──────────────┘
                    │                          │
            ┌───────▼──────────────────────────▼───────┐
            │     Users — trained, supported, measured │
            └──────────────────────────────────────────┘
```

## How to use this repo

1. **Fork it** into your organization's Git host.
2. Replace bracketed placeholders like `[ORG]`, `[SPONSOR]`, and `[CoE EMAIL]`.
3. Tailor `templates/acceptable-use-policy.md` with Legal and Security **before** broad launch.
4. Adapt `config-examples/` with your platform team and validate against current Anthropic documentation.
5. Track your rollout using `templates/90-day-launch-checklist.md`.

## Important note on product details

Claude and Claude Code evolve quickly. Plan names, admin features, configuration keys, and integrations referenced here reflect the author's understanding as of October 2026. **Always validate against the official documentation** at [docs.claude.com](https://docs.claude.com) and [support.claude.com](https://support.claude.com) before implementing.

This guide is independent and is not affiliated with or endorsed by Anthropic.
